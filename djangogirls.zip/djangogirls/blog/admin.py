from django.contrib import admin
from  .models import post

# Register your models here.
class Postadmin(admin.ModelAdmin):
	list_display = ('title' ,'author' ,'published','text')
	list_filter = ('title' , 'author')
	search_fields = ('title','text')
	

admin.site.register(post , Postadmin)
