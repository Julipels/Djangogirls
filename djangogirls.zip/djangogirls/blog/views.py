from django.shortcuts import render ,get_object_or_404
from django.utils import timezone
from django.http import HttpResponse
from .models import post
from .forms import EmailPostForm
from django.core.paginator import Paginator,EmptyPage 
from django.core.mail import send_mail


# Create your views here.
def post_list(request):
	# object_list = post.published.all()
	# #specifies 3 posts per page...awesome django
	# paginator = paginator(object_list,3)
	# page = request.GET.get('page')
	# try:
 #         posts = paginator.page(page)

	# except PageNotAnInteger:
	# 	#if the post is not an integer go to the first page
	# 	posts = paginator.page(1)
	# except EmptyPage:
	# 	#if page is last 
	# 	posts = paginator.page(paginator.num_page)
	
	#  # posts = post.objects.filter(published__lte=timezone.now()).order_by('published')
	data = {'hello' : post.objects.all()}

	return render(request,"blog/postlist.html",data)
def post_detail(request,pk):
	#view to displa all the post detail
	Post = get_object_or_404(post, pk=pk)
	return render(request , "blog/postdetail.html",{'post' : Post})
def post_new(request):
	# view to add post
    form = postform()
    forms = {'form': form()}
    return render(request, 'blog/post_edit.html', forms)
def home(request):
	data = {'hello' : post.objects.all()}
	return render(request ,'blog/postlist.html',data)
def about(request) :
	html = '<center> this is the about page </center>'

	return render(request , 'blog/about.html' , {})
	return HttpResponse('hello pal u are viewing my about page')
	
def contact(request):
	return render(request,'blog/contact.html' , {})



# def ShareEmail(request,post_id):
# 	#retrieve post with id
# 	post = get_object_or_404(post,id=post_id)
# 	if request.method == 'POST':
# 		form = EmailPostForm(request.POST)
# 		if form.is_valid():
# 			#form data passed validation
# 			cd = form.cleaned_data
# 			post_url = request.build.absolute_url(post.get_absolute_url())
# 			subject  = 

# 			#--send email
# 	else:
# 		form = EmailPostForm()
# 	return render(request , 'blog/share.html' , {'post':post,'form' : form})
		
